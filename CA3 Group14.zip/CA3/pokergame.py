from pokerview import *
from pokermodel import *
import sys

playernames = ['Fredrik', 'David']
playerbalances = [2000, 2500]
game = TexasHoldemModel(playernames, playerbalances)

qt_app = QApplication(sys.argv)
view = TexasHoldemView(game)
view.show()
qt_app.exec_()
