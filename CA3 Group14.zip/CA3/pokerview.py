#Imports
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtSvg import *
from PyQt5 import QtCore
from PyQt5 import QtGui
from pokermodel import *

class TableScene(QGraphicsScene):
    def __init__(self):
        super().__init__()
        self.tile = QPixmap('cards/table.png')
        self.setBackgroundBrush(QBrush(self.tile))

class CardItem(QGraphicsSvgItem):
    """ A simple overloaded QGraphicsSvgItem that also stores the card position """
    def __init__(self, renderer, position):
        super().__init__()
        self.setSharedRenderer(renderer)
        self.position = position

def read_cards():
    """
    Reads all the 52 cards from files.
    :return: Dictionary of SVG renderers
    """
    all_cards = dict()  # Dictionaries let us have convenient mappings between cards and their images
    for suit_file, suit in zip('CDHS', range(4)):
        for value_file, value in zip(['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'], range(2, 15)):
            file = value_file + suit_file
            key = (value, suit)  # I'm choosing this tuple to be the key for this dictionary
            all_cards[key] = QSvgRenderer('cards/' + file + '.svg')
    return all_cards

class CardsView(QGraphicsView):
    """ A View widget that represents the table area displaying a players cards. """

    back_card = QSvgRenderer('cards/Red_Back_2.svg')
    all_cards = read_cards()

    def __init__(self, cards_model: CardsModel, card_spacing: int = 250, padding: int = ()):
        """
        Initializes the view to display the content of the given model
        :param cards_model: A model that represents a set of cards. Needs to support the CardsModel interface.
        :param card_spacing: Spacing between the visualized cards.
        :param padding: Padding of table area around the visualized cards.
        """
        self.scene = TableScene()
        super().__init__(self.scene)

        self.card_spacing = card_spacing
        self.padding = padding

        self.model = cards_model
        self.model.new_cards.connect(self.__change_cards)

        self.__change_cards()

    def __change_cards(self):  # the double underscore is used to indicate that this is a private method.
        # Add the cards from scratch
        self.scene.clear()
        for i, card in enumerate(self.model):
            # The ID of the card in the dictionary of images is a tuple with (value, suit), both integers
            graphics_key = (card.get_value(), card.suit.value)
            # change to card.suit.value from card.suit
            renderer = self.back_card if self.model.flipped() else self.all_cards[graphics_key]
            c = CardItem(renderer, i)

            # Shadow effects
            shadow = QGraphicsDropShadowEffect(c)
            shadow.setBlurRadius(10.)
            shadow.setOffset(10, 10)
            shadow.setColor(QColor(0, 0, 0, 180))  # Semi-transparent black!
            c.setGraphicsEffect(shadow)

            # Place the cards on the default positions
            c.setPos(c.position * self.card_spacing, 0)
            self.scene.addItem(c)

    def update_view(self):
        scale = (self.viewport().height()-2*self.padding)/(313*1.25)
        self.resetTransform()
        self.scale(scale, scale)

    def resizeEvent(self, painter):
        # This method is called when the window is resized.
        self.update_view()
        super().resizeEvent(painter)


class MyTableView(QGroupBox):
    """
    MyTableView adds the TableContent and CardView widgets together to form a table
    """
    def __init__(self, game):
        super().__init__('Table')

        table_layout = QVBoxLayout()
        self.setLayout(table_layout)
        table_layout.addWidget(TableContent(game))
        table_layout.addWidget(CardsView(game.table, card_spacing=250,padding=10))

class TableContent(QGroupBox):
    """
    TableContent displays the total pot of the current round (and player bets)
    """
    def __init__(self, game):
        super().__init__()
        self.game = game
        tablecontent_layout = QVBoxLayout()
        self.setLayout(tablecontent_layout)

        #Total pot
        totalpot_layout = QHBoxLayout()
        self.total_pot = QLabel(f"Total pot: {self.game.pot} sek")

        totalpot_layout.addWidget(self.total_pot)
        totalpot_layout.setAlignment(Qt.AlignCenter)

        # Adding total pot to layout
        tablecontent_layout.addLayout(totalpot_layout)

        # Connect logic
        self.game.money_changed.connect(self.update_pot)

        self.update_pot()

    def update_pot(self):
        self.total_pot.setText(f"Total pot: {self.game.pot} sek")

class PlayersActionView(QGroupBox):
    """
    PlayersActionView adds both players views together with the action view,
    containing the action buttons Call/Raise Bet/Fold
    """
    def __init__(self, game):
        super().__init__('Players')

        playeraction_layout = QHBoxLayout()
        self.setLayout(playeraction_layout)
        self.player_views = [PlayerView(i, game) for i in range(len(game.players))]
        playeraction_layout.addWidget(self.player_views[0])
        playeraction_layout.addWidget(ActionView(game))
        playeraction_layout.addWidget(self.player_views[1])


class ActionView(QGroupBox):
    """
    ActionView contains the action buttons Call/Raise Bet/Fold and the QSpinbox that allows
    the user to set the Bet amount
    """
    def __init__(self, game):
        super().__init__('Action Buttons')
        self.game = game
        self.active_player = self.game.turn
        self.player_balance = game.players[self.active_player].money_amount
        action_layout = QVBoxLayout()
        self.setLayout(action_layout)

        # Call/Raise Bet/Fold Action Section

        self.call_button = QPushButton(f"Call")
        self.call_button.setFixedSize(QtCore.QSize(200, 110))
        action_layout.addWidget(self.call_button)
        action_layout.setAlignment(Qt.AlignCenter)

        self.raise_bet_button = QPushButton(f"Raise Bet")
        self.raise_bet_button.setFixedSize(QtCore.QSize(200, 110))
        action_layout.addWidget(self.raise_bet_button)
        action_layout.setAlignment(Qt.AlignCenter)

        # Bet amount
        self.bet_box = QSpinBox(self)
        self.bet_box.setMinimum(50)
        if self.game.players[self.game.turn].money_amount > self.game.players[self.game.notturn].money_amount:
            self.bet_box.setMaximum(self.game.players[self.game.notturn].money_amount)
        else:
            self.bet_box.setMaximum(self.game.players[self.game.turn].money_amount)
        self.bet_box.setSingleStep(50)
        self.bet_box.setPrefix("Raise Bet: ")
        self.bet_box.setSuffix("SEK")
        self.bet_box.setFixedSize(QtCore.QSize(200, 90))
        action_layout.addWidget(self.bet_box)

        self.fold_button = QPushButton(f"Fold")
        self.fold_button.setFixedSize(QtCore.QSize(200, 110))
        action_layout.addWidget(self.fold_button)
        action_layout.setAlignment(Qt.AlignCenter)

        # Controller part
        def call_view():
            game.call()

        def raise_bet_view():
            self.value = self.bet_box.value()
            game.raise_bet(self.value)

        def fold_view():
            game.fold()

        # Connect logic
        self.game.player_turn_changed.connect(self.update_view)
        self.game.raised_twice.connect(self.remove_raise_view)
        self.game.no_raise.connect(self.add_raise_view)

        self.call_button.clicked.connect(call_view)
        self.raise_bet_button.clicked.connect(raise_bet_view)
        self.fold_button.clicked.connect(fold_view)

        self.update_view()


    def update_view(self):
        if self.game.players[self.game.turn].money_amount > self.game.players[self.game.notturn].money_amount:
            self.bet_box.setMaximum(self.game.players[self.game.notturn].money_amount)
        else:
            self.bet_box.setMaximum(self.game.players[self.game.turn].money_amount)

    def remove_raise_view(self):
        self.raise_bet_button.hide()

    def add_raise_view(self):
        self.raise_bet_button.show()


class PlayerView(QGroupBox):
    """
    PlayerView displays the players balance, hand, whose turn it is, and a hide/show button for the active player
    """
    def __init__(self, whichplayer, game):
        player = game.players[whichplayer]
        super().__init__(player.name)

        self.whichplayer = whichplayer
        self.player = player
        self.game = game

        player_view_layout = QHBoxLayout()
        self.setLayout(player_view_layout)

        #Active player/Balance/Bet-amount layout
        balancebet_layout = QVBoxLayout()
        self.active_playerlabel = QLabel("Your turn")
        balancebet_layout.addWidget(self.active_playerlabel)

        # Balance
        self.balance_label = QLabel()

        # Adds to layout
        balancebet_layout.addWidget(self.balance_label)
        balancebet_layout.setAlignment(Qt.AlignCenter)

        # Cards/Flip
        cardsflip_layout = QVBoxLayout()

        # Flip button
        self.activebutton = QPushButton("Hide/Show Cards")
        self.activebutton.clicked.connect(self.player.hand.flip)
        cardsflip_layout.addWidget(self.activebutton)

        # Cards on hand
        cards_on_hand = CardsView(self.player.hand, card_spacing=250, padding=10)
        cardsflip_layout.addWidget(cards_on_hand)


        # Adding layouts together
        if self.whichplayer == 0:
            player_view_layout.addLayout(cardsflip_layout)
            player_view_layout.addLayout(balancebet_layout)
        else:
            player_view_layout.addLayout(balancebet_layout)
            player_view_layout.addLayout(cardsflip_layout)


        # Connect logic
        self.player.balance_changed.connect(self.update_balance)


        self.update_balance()

    def update_bet(self):
        self.game.raise_bet(self.bet_box.value())

    def update_balance(self):
        self.balance_label.setText(f"Balance: {self.player.money_amount} sek")
        #self.bet_amount.

    def set_active(self):
        self.activebutton.show()
        self.active_playerlabel.show()

    def set_inactive(self):
        self.activebutton.hide()
        self.active_playerlabel.hide()
        if self.player.hand.flipped() == False:
            self.player.hand.flip()


class TexasHoldemView(QWidget):
    """
    TexasHoldemView displays the entire game, containing the Table View and the PlayersActionView
    it also stores who the active player is, alerts the winner, and alerts players if they run out of money
    """
    def __init__(self, game):
        super().__init__()
        self.game = game
        self.turn = game.turn
        self.notturn = game.notturn
        self.player_hand = game.players[self.turn].hand
        self.otherplayer_hand = game.players[self.notturn].hand

        vbox = QVBoxLayout()
        vbox.addWidget(MyTableView(game))
        self.players_action_view = PlayersActionView(game)
        vbox.addWidget(self.players_action_view)

        self.setLayout(vbox)
        self.setWindowState(Qt.WindowMaximized)
        self.setWindowIcon(QtGui.QIcon('cards/pokericon.png'))
        self.setWindowTitle("Daves Dunkers: Texas hold'em")

        # Connect logic
        self.game.winner_found.connect(self.alert_winner)
        self.game.player_ran_out_of_money.connect(self.alert_out_of_money)
        self.game.player_turn_changed.connect(self.update_active_player)

        self.update_active_player()

    def update_active_player(self):
        for i, pv in enumerate(self.players_action_view.player_views):
            if i == self.game.turn:
                pv.set_active()
            else:
                pv.set_inactive()

    def alert_winner(self, text: str):
        self.player_hand.flip()
        self.otherplayer_hand.flip()
        msg = QMessageBox()
        msg.setText(text)
        msg.exec()
        self.player_hand.flip()
        self.otherplayer_hand.flip()

    def alert_out_of_money(self, text: str):
        msg = QMessageBox()
        msg.setText(f'{text} ran out of money!')
        msg.setInformativeText("Please visit <a href='https://stodlinjen.se/'>Stödlinjen</a> to get help!")
        msg.exec()
        self.close()